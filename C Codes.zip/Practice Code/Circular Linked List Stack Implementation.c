#include <stdio.h>
#include <conio.h>

struct node
{
    int data;
    struct node *link;
};
struct node *start;

void PUSH(int item)
{
    struct node *p = start;
    struct node *newNode = (struct node *)malloc(sizeof(struct node));
    newNode->data = item;
    newNode->link = start;
    
    if (start == NULL){
        start = newNode;
        newNode->link = newNode;
        return;
    }
    
    while(p->link != start)
    {
        p = p->link;
    }
    
    p->link = newNode;
    start = newNode;
}

void POP ()
{
    struct node *p = start;
    
    if (start == NULL){
        printf("UnF condition.\n");
        return;
    }
    
    while(p->link != start){
        p = p->link;
    }
    
    start = start->link;
    p->link = start;
}

void display ()
{
    struct node *p = start;
    if (start == NULL){
        printf("UnF condition.\n");
        return;
    }
    while(p->link != start){
        printf("%d \n",p->data);
        p = p->link;
    }
    
    printf("%d \n",p->data);
    
}

void main()
{
    POP();
    display();
}












