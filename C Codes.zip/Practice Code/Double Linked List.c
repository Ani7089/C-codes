#include <stdio.h>
#include <conio.h>

struct node
{
    struct node *prev;
    int info;
    struct node *next;
}

void dLLInsertFront( struct node *p, int item)
{
    struct node *newNode = (struct node *)malloc(sizeof(struct node));
    newNode->info = item;
    newNode->next = p;
    newNode->prev = NULL;
    p = newNode;
}

void dLLInsertLast(struct node *p, int item)
{
    struct node *p1
    struct node *newNode = (struct node *)malloc(sizeof(struct node));
    newNode->info = item;
    newNode->next = NULL;
    
    if(p == NULL){
        p = newNode;
        newNode->prev = p;
        return;
    }
    
    while(p1->next != NULL)
    {
        p1 = p1->next;
    }
    
    p1->next = newNode;
    newNode->prev = p;
    
}

void dllInsertAfterX (struct node *p, int x, int item)
{
    struct node *newNode = (struct node *)malloc(sizeof(struct node));
    newNode->info = item;
    struct node *p1 = p;
    
    if (p == NULL)
    {
        printf("UnF condition.\n");
        return;
    }
    
    while (p1->next != NULL && p1->info != x)
    {
        p = p->next;
    }
    
    if(p->info == x)
    {
        newNode->next = p1->next;
        newNode->prev = p1;
        p1->next = newNode;
        p1 = p1->link;
        p1->prev = newNode;
        return;
    }
    
    printf("Variable not found in linked list.\n");
    
}

void dLLInsertBeforeX(struct node *lp, int x, int item)
{
    struct node *newNode = (struct node *)malloc(sizeof(struct node));
    newNode->info = item;
    struct node *p = lp;
    
    if (lp == NULL)
    {
        printf("UnF condition.\n");
        return;
    }
    
    while(p->next !=NULL && p->info != x)
    {
        p = p->next;
    }
    
    if (p->info == x)
    {
        newNode->next = p;
        newNode->prev = p->prev;
        p = newNode->prev;
        p->next = newNode;
        return;
    }
    
    printf("Item not found in list.\n");
}

void dLLDeleteFirst(struct node *p1)
{
    if(p1 == NULL){
        printf("UnF condition.\n");
        return;
    }
    
    if (p1->next == NULL){
        p1 = NULL;
        return;
    }
    
    p1 = p1->next;
    p1->prev = NULL;
    
}

void dLLDeleteLast(struct node *p1)
{
    struct node *p = p1->prev;
    if(p1 == NULL)
    {
        printf("UnF condition.\n");
        return;
    }
    
    while(p->next != NULL){
        p = p->next;
    }
    
    p->prev->next = NULL;
}

void dLLDeleteX(struct node *p1, int x)
{
    struct node *p = p1;
    if(p1 == NULL)
    {
        printf("UnF condition.\n");
        return;
    }
    
    while(p->info != x && p->next != NULL)
    {
        p = p->next;
    }
    
    p->prev->next = p->next;
    
}

void main(){
    
}


















