#include <stdio.h>
#include <conio.h>

struct node
{
    int data;
    struct node *link;
};

struct node *start;

void PUSH (int item)
{
    struct node *newNode = (struct node *)malloc(sizeof(struct node));
    newNode->data = item;
    
    newNode->link = start;
    start = newNode;
    return;
}

void POP()
{
    if(start == NULL){
        printf("UnF condition.\n");
        return;
    }
    
    start = start->link;
    
}

void display()
{
    struct node *p = start;
    if(start == NULL){
        printf("UnF condition.\n");
        return;
    }
    
    while(p){
        printf("%d \n", p->data);
        p = p->link;
    }
}

void main ()
{
    start = NULL;
    POP();
    PUSH(20);
    PUSH(10);
    POP();
    display();
}












