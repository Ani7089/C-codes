#include <stdio.h>
#include <conio.h>

struct node
{
    int data;
    struct node *link;
};

struct node *r = NULL, *f = NULL;

void Enqueue(int item)
{
    struct node *newNode = (struct node *)malloc(sizeof(struct node));
    newNode->data = item;
    
    if (f == NULL){
        f = newNode;
        r = newNode;
        newNode->link = newNode; 
        return;
    }
    
    
    newNode->link = f;
    r->link = newNode;
    r = newNode;
}

void Dequeue ()
{
    if (f == NULL){
        printf("UnF condition.\n");
        return;
    }
    
    if (f == f->link){
        f = NULL;
        r = NULL;
        return;
    }
    
    f = f->link;
    r->link = f;
}

void display ()
{
    struct node *p = f;
    if (f == NULL){
        printf("UnF condition.\n");
        return;
    }
    while(p != r){
        printf("%d \n",p->data);
        p = p->link;
    }
    
    printf("%d \n",p->data);
    
}

void main()
{
    Dequeue();
    display();
    Enqueue(10);
    
    display();
}












