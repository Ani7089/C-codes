#include <stdio.h>
#include <conio.h>

int a[20];
int *p = &a[0];

void PUSH(int item)
{
    a[p - &a[0]] = item;
    p++;
    
}

void POP()
{
    if(p == &a[0]){
        printf("UnF condition,\n");
        return;
    }
    p--;
    
}

void display()
{
    int i;
    if (p == &a[0]){
        printf("UnF condition.\n");
        return;
    }
    
    for(i = p - &a[0] -1; i>=0; i--){
        printf("%d \n",a[i]);
    }
}

void main()
{
    PUSH(10);
    PUSH(20);
    PUSH(30);
    PUSH(40);
    PUSH(50);
    PUSH(60);
    PUSH(70);
    POP();
    display();
}







