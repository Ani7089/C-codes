#include <stdio.h>
#include <conio.h>

struct node
{
    int info;
    struct node *prev;
    struct node *next;
}

void cDLLInsertFirst(struct node *p1, int item)
{
    struct node *newNode = (struct node *)malloc(sizeof(struct node));
    newNode->info = item;
    newNode->next = p1;
    newNode->prev = p1->prev;
    p1->prev = newNode;
    p1 = newNode;
    
}

void cDLLInsertLast(struct node *p1, int item)
{
    struct node *newNode = (struct node *)malloc(sizeof(struct node));
    newNode->info = item;
    newNode->next = p1;
    newNode->prev = p1->prev;
    p1->prev = newNode;
}

void cDLLInsertAfterX(struct node *p1, int item, int x)
{
    struct node *p = p1;
    struct node *newNode = (struct node *)malloc(sizeof(struct node));
    newNode->info = item;
    
    if (p==NULL)
    {
        printf("UnF condition.\n");
        return;
    }
    
    while(p->next != NULL && p->info != x)
    {
        p = p->next;
    }
    
    if(p->info == x)
    {
        newNode->next = p->next;
        newNode->prev = p;
        p->next->prev = newNode;
        p->next = newNode;
        return;
    }
    
    printf("Item not found.\n");
}

void cDLLInsertBeforeX(struct node *p1, int item, int x)
{
    struct node *p = p1;
    struct node *newNode = (struct node *)malloc(sizeof(struct node));
    newNode->info = item;
    
    if(p == NULL)
    {
        printf("UnF condition.\n");
        return;
    }
    
    while(p->next != NULL && p->info != x)
    {
        p = p->next;
    }
    
    if (p->info == x)
    {
        p->prev->next = newNode;
        newNode->prev = p ->prev;
        newNode->next = p;
        p->prev = newNode;
        return;
    }
    
    printf("Item not found.\n");
    
}

void cDLLDeleteFront(struct node *p1)
{
    if (p == NULL)
    {
        printf("UnF condition.\n");
        return;
    }
    
    p1->prev->next = p1->next;
    p1 = p1->next;
    
}

void cDLLDeleteLast(struct node *p1)
{
    if(p1 == NULL)
    {
        printf("UnF condition.\n");
        return;
    }
    
    p1->prev->prev->next = p1;
}

void cDLLDeleteX(struct node *p1, int item)
{
    struct node *p = p1;
    
    while(p->next != p1)
    {
        if(p->info == item)
        {
            p->prev->next = p->next;
            p->next->prev = p->prev;
            return;
        }
    }
    
    printf("Item not found.\n");
}

void cDLLDeleteAfterX(struct node *p1, int x)
{
    struct node *p = p1;
    
    while(p->next != p1)
    {
        
    }
}

void main()
{
    
}














