#include <stdio.h>
#include <conio.h>

int a[20];
int *p = a;
int *f = a;

void Enqueue(int item)
{
    a[p-a] = item;
    p++;
}

void Dequeue()
{
    if(p == a){
        printf("UnF condition,\n");
        return;
    }
    f++;
    
}

void display()
{
    int i;
    if (p == &a[0]){
        printf("UnF condition.\n");
        return;
    }
    
    for(i = f-a; i<p-a; i++){
        printf("%d \n",a[i]);
    }
}

void main()
{
    Enqueue(10);
    Enqueue(20);
    Enqueue(30);
    Enqueue(40);
    Enqueue(50);
    Enqueue(60);
    Enqueue(70);
    Dequeue();
    display();
}







