#include <stdio.h>
#include <conio.h>

struct node
{
    int info;
    struct node *link;
};
struct s 
{
    struct node *start;
};

void IN_LAST (struct s *sp, int item)
{
    struct node *p;
    struct node *newNode = (struct node *)malloc(sizeof(struct node));
    newNode->info = item;
    newNode->link = NULL;
    
    if (sp->start == NULL){
        sp->start = newNode;
        return;
    }
    
    p = sp->start;
    
    while(p->link != NULL){
        p = p->link;
    }
    
    p->link = newNode;
    
}

void display (struct node *p)
{
    if (!p){
        printf("UnF condition\n");
        return;
    }
    while(p){
        printf("%d\n",p->info);
        p = p->link;
    }
}

void IN_FIRST(struct s *lp, int item)
{
    struct node *newNode = (struct node *)malloc(sizeof(struct node));
    newNode->info = item;
    
    if (lp->start == NULL){
        lp->start = newNode;
        newNode->link = NULL;
        return;
    }
    
    newNode->link = lp->start;
    lp->start = newNode;
    return;
}

void IN_AfterX(struct s *lp, int item, int AFTER)
{
    struct node *p;
    struct node *newNode = (struct node *)malloc(sizeof(struct node));
    newNode->info = item;
    
    if (lp->start == NULL){
        printf("UnF condition.\n");
        return;
    }
    
    if(lp->start->link == NULL){
        if (lp->start->info == AFTER){
            lp->start->link = newNode;
            newNode->link = NULL;
            return;
        }
        printf("Item not found in list.\n");
        return;
    }
    
    p = lp->start;
    
    while(p->link != NULL && p->info != AFTER){
        p = p->link;
    }
    
    if (p->info == AFTER){
        newNode->link = p->link;
        p->link = newNode;
      //  printf("Insertion IN_AfterX\n");
    }else{
        printf("Item not found");
    }
    
    
}


void IN_BeforeX(struct s *lp, int item, int BEFORE)
{
    struct node *p;
    struct node *newNode = (struct node *)malloc(sizeof(struct node));
    newNode->info = item;
    
    if (lp->start == NULL){
        printf("Unf condition\n");
        return;
    }
    
    if (lp->start->info == BEFORE){
        newNode->link = lp->start;
        lp->start = newNode;
        return;
    }
    
    p = lp->start;
    
    while(p->link->link != NULL && p->link->info != BEFORE){
        p = p->link;
    }
    
    if(p->link->info == BEFORE){
        newNode->link = p->link;
        p->link = newNode;
        return;
    }else {
        printf("Item not found\n");
    }
}

void deleteFirstNode(struct s *lp)
{
    if (lp->start == NULL){
        printf("Unf condition\n");
        return;
    }
    
    lp->start = lp->start->link;
    //printf("Delete Succesfully\n");
}

void deleteLastNode(struct s *lp)
{
    struct node *p;
    if(lp->start == NULL){
        printf("UnF condition.\n");
        return;
    }
    
    if (!lp->start->link){
        lp->start = NULL;
        return;
    }
    
    p = lp->start;
    
    while(p->link->link)
    {
        p = p->link;
    }
    
    p->link = NULL;
}

void deleteXNode(struct s *lp, int item)
{
    struct node *p;
    if(lp->start == NULL){
        printf("Unf condition.\n");
        return;
    }
    
    if(lp->start->link == NULL){
        if(lp->start->info == item){
            lp->start = NULL;
            return;
        }
        printf("item not found.\n");
        return;
    }
    
    p = lp->start;
    
    while(p->link->link && p->link->info != item)
    {
        p = p->link;
    }
    
    if (p->link->info == item )
    {
        p->link = p->link->link;
        return;
    }
    
    printf("Item not Found.\n");
}

void searchItem(struct s *lp, int item)
{
    struct node *p = lp->start;
    while(p->link && p->info != item){
        p = p->link;
    }
    
    if (p->info == item)
        printf("%d found in List.\n",item);
    else
        printf("%d not found in List.\n",item);
    
}

int numberNode (struct s *lp)
{
    int count = 0;
    struct node *p = lp->start;
    
    while(p)
    {
        p = p->link;
        count++;
    }
    return count;
}

int freqItem(struct s *lp, int item)
{
    int count = 0;
    struct node *p = lp->start;
    while(p)
    {
        if(p->info == item)
            count++;

        p = p->link;
    }
    return count;
}


void main()
{
    struct s l;
    l.start = NULL;
    IN_FIRST(&l, 1);
    IN_FIRST(&l, 1);
    IN_FIRST(&l, 1);
    IN_FIRST(&l, 1);
    IN_FIRST(&l, 1);
    IN_FIRST(&l, 1);
    IN_FIRST(&l, 1);
    IN_FIRST(&l, 2);
    IN_FIRST(&l, 1);
    IN_FIRST(&l, 1);
    IN_FIRST(&l, 2);
    printf("Number of nodes = %d\n",numberNode(&l));
    printf("frequency of ONE = %d\n",freqItem(&l,1));
    //display(l.start);
}














