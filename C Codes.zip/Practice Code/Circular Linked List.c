/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <conio.h>

struct node
{
    int info;
    struct node *link;
};

void firstInsert(struct node **lp, int item)
{
    struct node *p;
    struct node *newNode = (struct node *)malloc(sizeof(struct node));
    newNode->info = item;
    
    if (*lp == NULL)
    {
        *lp = newNode;
        newNode->link = newNode;
        return;
    }
    p = *lp;
    
    while(p->link != *lp){
        p = p->link;
    }
    
    p->link = newNode;
    newNode->link = *lp;
    
    *lp = newNode;
    
}

void lastInsert (struct node **lp, int item)
{
    struct node *p;
    struct node *newNode = (struct node *)malloc(sizeof(struct node));
    newNode->info = item;
    
    if (*lp == NULL)
    {
        *lp = newNode;
        newNode->link = newNode;
        return;
    }
    
    p = *lp;
    
    while(p->link != *lp){
        p = p->link;
    }
    
    p->link = newNode;
    newNode->link = *lp;
    
}

void display (struct node **lp)
{
    struct node *p = *lp;
    if (*lp == NULL)
    {
        printf("UnF condition.\n");
        return;
    }
    
    while(p->link != *lp)
    {
        printf("%d \n",p->info);
        p = p->link;
    }
    
    printf("%d\n",p->info);
    
}

void deleteFirstNode(struct node **lp)
{
    struct node *p = *lp;
    if( *lp == NULL)
    {
        printf("UnF condition.\n");
        return;
    }
    
    if (*lp == (*lp)->link){
        *lp = NULL;
        return;
    }
    
    while(p->link != *lp)
    {
        p = p->link;
    }
    
    p->link = (*lp)->link;
    *lp = (*lp)->link;
    
}

void deleteLastNode(struct node **lp)
{
    struct node *p = *lp;
    if (*lp == NULL){
        printf("UnF condition.\n");
        return;
    }
    
    if (*lp == (*lp)->link){
        *lp = NULL;
        return;
    }
    
    while(p->link->link != *lp)
    {
        p = p->link;
    }
    
    p->link = *lp;
    
}

void main()
{
    struct node *start = NULL;
    display(&start);
    firstInsert ( &start, 10);
    lastInsert(&start, 20);
    firstInsert(&start, 30);
    display( &start);
    deleteLastNode(&start);
    deleteFirstNode(&start);
    display(&start);

}









