#include <stdio.h>
#include <conio.h>

struct node 
{
    int info;
    struct node *link;
}

void concatinat(struct node *p1, struct node ^p2)
{
    struct node *p = p1;
    if (p1 == NULL){
        p1 = p2;
        return;
    }
    while(p->link != NULL){
        p = p->link;
    }
    
    p->link = p2;
}

void Union(struct node *p1, struct node *p2)
{
    struct node *p = p1;
    struct node *cp = p2;
    struct node *r = cp;
    struct node *s = NULL;
    
    if (cp == NULL)
    {
        return;
    }
    
    if (p == NULL)
    {
        p = cp;
        return;
    }
    
    while(p != NULL)
    {
        while(cp != NULL)
        {
            if(p->lnfo == cp->info)
            {
                if(cp == p2)
                {
                    cp = cp->link;
                    continue;
                }
                
                r->link = cp->link;
                r = cp;
                cp = cp->link;
                
            }
            
            cp = cp->link;
        }
        
        if(p->link == NULL){
              s = p; 
        }
        
        p = p->link;
    }
    
    s->link = p2;
    
}

void Intersection(struct node *p1, struct node *p2)
{
    struct node *p = p1;
    struct node *l = p2;
    struct node *r = p;
    
    if(p == NULL && l == NULL)
    {
        p = NULL;
    }
    
    while(p != NULL)
    {
        while(l != NULL)
        {
            if (p->info == l->info)
            {
                r->link = p->link;
                break;  
            }
            
            l = l->link;
        }
        r=p;
        p = p->link;
    }
    
}

void main()
{
    struct node *lp = NULL;
    
}








